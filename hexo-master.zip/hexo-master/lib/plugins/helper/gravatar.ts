import { gravatar } from 'hexo-util';
export = gravatar;
